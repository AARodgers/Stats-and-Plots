# Using Numpy

import numpy as np

a = np.array([1,2])
b = np.array([3,4])
c = a + b
print(c)

# In terminal: 
# Check python version: python3 --version
# Install numpy: pip install numpy ( doesn't work)
# Run the program: python3 hello_world.py
